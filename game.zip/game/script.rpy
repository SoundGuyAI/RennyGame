﻿# Renny — café date demo scene (placeholder art only).

define alex = Character("Alex", color="#6eb5ff")
define jordan = Character("Jordan", color="#ffb86b")

# Solid-color backgrounds and Ren'Py placeholder sprites (no external art).
image bg cafe = Solid("#3d2b1f")
image bg cafe_window = Solid("#5c4033")

image alex neutral = Placeholder("boy")
image alex smile = Placeholder("boy")
image jordan neutral = Placeholder("girl")
image jordan smile = Placeholder("girl")

label start:

    scene bg cafe
    with dissolve

    "Rain taps the windows of Corner Cup, a small café downtown."
    "Jordan is already at the table, latte in hand, when Alex arrives."

    show jordan smile at center
    with dissolve

    jordan "You made it! I was starting to think the bus got you."

    show alex smile at left
    show jordan neutral at right
    with dissolve

    alex "Only by five minutes. The line was longer than the menu."

    jordan "Fair. I ordered you something — hope that's okay."

    alex "You remembered I like oat milk. Dangerously thoughtful."

    jordan "So… how's your week been? Besides surviving public transit."

    menu:
        "Talk about work.":
            jump choice_work
        "Talk about hobbies.":
            jump choice_hobbies

label choice_work:

    alex "Busy, but good. We finally shipped the feature I've been nursing for months."

    jordan "That's huge. Did you celebrate, or collapse at your desk?"

    alex "Both. A quiet victory lap, then sleep."

    jump date_ending

label choice_hobbies:

    alex "I started a tiny balcony garden. So far, one heroic tomato plant."

    jordan "A tomato with main-character energy. I respect it."

    alex "It gets more sunlight than I do lately."

    jump date_ending

label date_ending:

    hide alex
    hide jordan
    with dissolve

    scene bg cafe_window
    with dissolve

    show jordan smile at center
    with dissolve

    jordan "This was really nice. Same time next week?"

    alex "Yeah. I'll even try to be on time."

    jordan "I'll hold you to that."

    "They linger until the cups are empty, then step out into the cool evening."

    return
