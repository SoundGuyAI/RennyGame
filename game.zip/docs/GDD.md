# Renny — Game Design Document

> **Status:** Game design **not started**. The playable build today is a **pipeline test scene** only (see [Appendix A](#appendix-a-pipeline-test-scene-not-the-game)). Do **not** treat that scene as the game's concept, characters, or story.
>
> Update this document when the **real** game is defined and as features are implemented. Keep design sections **TBD** until then.

| Field | Value |
|-------|--------|
| Engine | Ren'Py **8.5.3** (`8.5.3.26051504`) |
| Primary platform | **Mobile web** (HTML5 via RenPyWeb) |
| Play URL (test build) | [https://soundguyai.github.io/RennyGame/](https://soundguyai.github.io/RennyGame/) |
| Source repo | [SoundGuyAI/Renny](https://github.com/SoundGuyAI/Renny) |

---

## 1. Concept / logline

**TBD**

---

## 2. Genre and tone

| | |
|---|---|
| **Genre** | TBD |
| **Tone** | TBD |
| **Rating / content limits** | TBD |

---

## 3. Target audience and platform

| | |
|---|---|
| **Audience** | TBD |
| **Platform (primary)** | **Mobile web** — Ren'Py HTML5 build on GitHub Pages (phone playtesting) |
| **Platform (secondary)** | TBD (e.g. desktop launcher builds) |
| **Session length (target)** | TBD |

---

## 4. Core loop

**TBD**

---

## 5. Characters

**TBD** (cast, roles, and arcs for the actual game).

---

## 6. Story outline and routes / branching

**TBD**

| Route / arc | Status |
|-------------|--------|
| Main story | TBD |
| Branches / routes | TBD |
| Endings | TBD |

---

## 7. Choices and systems

| System | Status |
|--------|--------|
| Menu choices / branching logic | TBD |
| Relationship points / affection | TBD |
| Stats | TBD |
| Calendar / time | TBD |
| Inventory / gifts | TBD |
| Meta-UI (phone, map, etc.) | TBD |

---

## 8. Art direction

| Asset type | Status |
|------------|--------|
| Character art | TBD |
| Backgrounds | TBD |
| GUI / theme | Default Ren'Py 8 template in repo today; **custom art TBD** |
| UI safe areas (mobile web) | TBD — validate on target devices via RennyGame URL |

**Until real art exists:** use Ren'Py `Solid` / `Placeholder` in code; no unlicensed external story assets.

---

## 9. Audio

| | |
|---|---|
| Music | TBD |
| Ambience / SFX | TBD |
| Voice acting | TBD |

---

## 10. UI / UX

| Topic | Status |
|-------|--------|
| Input (touch / keyboard) | TBD |
| Mobile web UX | **Pipeline validated** via RennyGame Pages; game-specific UX TBD |
| Save / load | TBD |
| Accessibility | TBD |
| Skip / auto-forward | TBD |

---

## 11. Scope and milestones

| Milestone | Status |
|-----------|--------|
| M0 — Ren'Py project + lint + web build + deploy to RennyGame | **Done** |
| M0b — Pipeline test scene in `game/script.rpy` (dialogue + menu + placeholders) | **Done** (technical only; **not** game content) |
| M1 — Game concept and GDD sign-off | TBD |
| M2 — First real story vertical slice | TBD |
| M3+ | TBD |

---

## 12. Open questions

- [ ] Logline and central conflict?
- [ ] Protagonist and POV?
- [ ] Genre, tone, and content rating?
- [ ] Cast and route structure?
- [ ] Endings and replay value?
- [ ] Monetization / distribution (if any)?
- [ ] Target playtime and word count?
- [ ] Localization?

---

## Appendix A — Pipeline test scene (NOT the game)

The following exists **only** to verify **build → deploy → phone playtesting**. It is disposable placeholder content and must **not** be copied into design sections above.

| Item | Detail |
|------|--------|
| Location in repo | `game/script.rpy` |
| Purpose | Smoke-test Ren'Py web export, GitHub Actions, and GitHub Pages |
| Characters | **Alex** and **Jordan** — fictional names for test dialogue only |
| Content | Short café conversation, one menu (work vs. hobbies), rejoin, end |
| Art | `Solid` backgrounds + `Placeholder` sprites |

Flow reference (for engineers, not design):

```
start → café banter → menu (work | hobbies) → shared ending → return
```

When the real game is written, this scene should be **replaced or removed**; the GDD should describe the new game, not this test.

---

## Document history

| Date | Change |
|------|--------|
| 2026-10-23 | Initial GDD template; pipeline test scene documented in appendix only |
