# Renny

**Renny** is a Ren'Py 8.5 visual novel project. **Game design is not defined yet** — see [`docs/GDD.md`](docs/GDD.md).

What you can play today at the link below is **not the game**. It is a **placeholder test scene** (a café conversation between **Alex** and **Jordan**) used only to verify **lint, web build, deploy, and phone playtesting**. Those names, setting, and dialogue are throwaway pipeline smoke content, not the project's concept or canon.

| | |
|---|---|
| **Play (mobile web)** | [https://soundguyai.github.io/RennyGame/](https://soundguyai.github.io/RennyGame/) |
| **Source** | [SoundGuyAI/Renny](https://github.com/SoundGuyAI/Renny) (this repo) |
| **Hosted build** | [SoundGuyAI/RennyGame](https://github.com/SoundGuyAI/RennyGame) (GitHub Pages) |
| **Engine** | [Ren'Py 8.5.3](https://github.com/renpy/renpy/releases/tag/8.5.3.26051504) (`8.5.3.26051504`) |
| **Design doc** | [`docs/GDD.md`](docs/GDD.md) |

Pushing to `main` in this repo automatically lints, builds the HTML5 version, and deploys to RennyGame so you can play the latest build on a phone without installing anything.

## Project layout

```
Renny/                          # Ren'Py project root (open this folder in the launcher)
  game/
    script.rpy                  # Pipeline test scene today; real story TBD (see GDD)
    options.rpy                 # Game name, build name, audio flags
    screens.rpy, gui.rpy        # UI (default Ren'Py GUI template)
    gui/                        # GUI image assets (stock template)
    images/                     # Future story art (bg/, character sprites); empty for now
    audio/                      # Future music/SFX
  docs/GDD.md                   # Game design document (TBD until real game is scoped)
  progressive_download.txt      # RenPyWeb progressive download rules
  scripts/build-web.sh          # Local web build helper
  .github/workflows/build-web.yml
  AGENTS.md                     # Instructions for AI coding agents
```

The Ren'Py **SDK is not committed**. CI downloads it on each run; for local work, install the SDK yourself (see below).

## Run locally (desktop)

1. Install the Ren'Py **8.5.3** SDK from [GitHub releases](https://github.com/renpy/renpy/releases/tag/8.5.3.26051504) if [renpy.org](https://www.renpy.org/) is unreachable.
2. Clone this repository.
3. In the Ren'Py launcher, select **preferences → projects directory** if needed, then open the **repository root** (`Renny/`) as the project.
4. Click **Launch Project**.

From a terminal (SDK path will vary):

```bash
/path/to/renpy-8.5.3-sdk/renpy.sh /path/to/Renny
```

### Lint (required before you commit script changes)

In the launcher: **Build → Lint**.

Or from the SDK directory:

```bash
./renpy.sh /path/to/Renny lint
```

Lint must complete with **exit code 0** and no reported script errors. CI runs the same check on every deploy.

### Web build on your machine

1. From the same release, download **renpy-8.5.3-web.zip**, unzip it, and copy the `web/` folder into your SDK directory (next to `renpy.py`). The launcher can also install web support when you first use **Web → Build**.
2. Build from this repo:

   ```bash
   ./scripts/build-web.sh
   ```

   Output: `build/web/` (open `index.html` via a local static server, or use the launcher’s **Build and Open in Browser**).

## Phone playtesting (auto-deploy to GitHub Pages)

Development flow:

1. Edit game scripts in **Renny** (`game/`).
2. Merge to **`main`**.
3. GitHub Actions (workflow [`.github/workflows/build-web.yml`](.github/workflows/build-web.yml)) runs on `ubuntu-latest`:
   - Downloads Ren'Py 8.5.3 SDK + web support
   - **Lint** the project
   - **web_build** into `build/web/`
   - Publishes `build/web/` to the **`gh-pages`** branch of **SoundGuyAI/RennyGame** using [peaceiris/actions-gh-pages](https://github.com/peaceiris/actions-gh-pages)
4. GitHub Pages serves that branch at the live URL: **[https://soundguyai.github.io/RennyGame/](https://soundguyai.github.io/RennyGame/)**

You can also trigger a deploy manually: **Actions → Build and publish web game → Run workflow**.

### One-time setup (already done for this project)

These steps are documented for new forks or if secrets/Pages are reset.

#### 1. Deploy secret on **Renny**

Cross-repo push requires a token; `GITHUB_TOKEN` in Renny cannot write to RennyGame.

1. Create a **personal access token** with **Contents: Read and write** on repository `SoundGuyAI/RennyGame` (fine-grained PAT), or a classic token with `repo` scope if appropriate.
2. In **SoundGuyAI/Renny** → **Settings** → **Secrets and variables** → **Actions**, add:

   | Secret name | Value |
   |-------------|--------|
   | `RENNYGAME_DEPLOY_TOKEN` | The PAT from step 1 |

The workflow references this as `secrets.RENNYGAME_DEPLOY_TOKEN` in the publish step.

#### 2. GitHub Pages on **RennyGame**

1. **SoundGuyAI/RennyGame** → **Settings** → **Pages**
2. **Build and deployment → Source:** Deploy from a branch
3. **Branch:** `gh-pages`, folder **`/ (root)`**
4. Save. After the first successful workflow run, the game is available at the live URL (may take a minute to propagate).

## Contributing

- Read [`AGENTS.md`](AGENTS.md) if you use an AI coding agent.
- Update [`docs/GDD.md`](docs/GDD.md) when you add or change story scope, characters, routes, or systems.
- Prefer small, focused pull requests; ensure **lint passes** before opening a PR.

## License

TBD.
