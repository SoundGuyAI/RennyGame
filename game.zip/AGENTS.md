# Agent instructions (Renny)

This file is for **AI coding agents** (and humans using them) working in [SoundGuyAI/Renny](https://github.com/SoundGuyAI/Renny). Follow it unless the user gives conflicting instructions for a specific task.

## What this repo is

- **Renny** — Ren'Py 8.5.3 visual novel **source** (the actual game is **not designed yet**; see `docs/GDD.md`).
- **RennyGame** — separate public repo; hosts **HTML5 builds only** for GitHub Pages ([live play URL](https://soundguyai.github.io/RennyGame/)).
- **`game/script.rpy` today** — a **pipeline test scene** (Alex & Jordan café date). It exists to exercise **lint, web build, deploy, and mobile play**. **Do not treat it as the game's story, concept, or final cast.** Replace it when real game content is authored.
- Do **not** commit the Ren'Py SDK, `build/` output, `game/cache/`, or `game/saves/`.

## Repository layout

| Path | Purpose |
|------|---------|
| `game/script.rpy` | **Currently:** pipeline test scene only. **Future:** main story flow, characters, images, labels |
| `game/options.rpy` | `config.name`, `build.name`, audio flags, build classifiers |
| `game/screens.rpy`, `game/gui.rpy` | Screens and GUI styling (default template; change carefully) |
| `game/gui/` | Stock GUI PNGs (menus, textbox, buttons) |
| `game/images/` | **Story** backgrounds and character sprites (when added) |
| `game/audio/` | Music and sound effects |
| `docs/GDD.md` | Game design document — design sections stay **TBD** until the real game is defined; document pipeline test only in GDD appendix |
| `progressive_download.txt` | RenPyWeb download rules (usually leave as-is unless web perf needs tuning) |
| `scripts/build-web.sh` | Local web build helper |
| `.github/workflows/build-web.yml` | Lint + web build + deploy to RennyGame on push to `main` |

**Project root** for Ren'Py is the repo root (the directory that contains `game/`).

## Ren'Py conventions

### Scripts and flow

- Ren'Py script lives in `game/**/*.rpy`. Prefer **new `.rpy` files** for large features (e.g. `game/chapter01.rpy`) over one giant file, but match existing style.
- Use **`label`** for entry points and branches; use **`jump`** / **`call`** / **`return`** consistently.
- Narration: bare strings. Dialogue: `character "Line."`
- Menus: `menu:` / `"Choice text.":` / `jump` or inline script.

### Characters

- Define with `define name = Character("Display Name", ...)`.
- **Alex** and **Jordan** in `game/script.rpy` are **test-only** placeholders for the pipeline scene — not the official cast.
- For the real game, add characters per `docs/GDD.md` (e.g. `game/characters.rpy` when the cast is defined).

### Images (naming)

Ren'Py resolves `show alex smile` from image components:

- **Backgrounds:** `image bg <name> = ...` then `scene bg <name>`.
- **Sprites:** `image <character> <expression> = ...` then `show <character> <expression>`.
- **File-based art** (when used): place under `game/images/` using Ren'Py’s automatic naming, e.g. `game/images/bg cafe.png` → `bg cafe`, or `game/images/alex smile.png` → `alex smile`.

Until real art exists, use **`Solid("#hex")`** and **`Placeholder(...)`** for smoke content (as in the pipeline test scene). Do not expand café-date canon in docs when adding placeholders.

### Options and builds

- `build.name` in `options.rpy` must stay **ASCII**, no spaces (currently `renny`).
- Target engine: **8.5.3.26051504** (see README).

## Placeholder art rules

- **No external story art** unless the user or GDD explicitly requests it.
- Allowed without approval: `Solid`, `Placeholder`, and existing **stock `game/gui/`** assets.
- When adding real art: put files in `game/images/` (or subfolders), use consistent `image` names, update **GDD → Art direction**, and keep web build size reasonable.
- Do not embed large binary assets unrelated to the game.

## Lint (required before commit)

Always run lint after changing `.rpy` files and before committing.

With SDK installed:

```bash
cd /path/to/renpy-8.5.3-sdk
./renpy.sh /path/to/Renny lint
```

- **Exit code must be 0.**
- Fix reported errors; do not ignore lint failures.
- CI runs the same lint step; a failing lint blocks deploy.

Launcher equivalent: **Build → Lint**.

## Web build and deploy

### Local

1. Install SDK + copy `web/` from `renpy-8.5.3-web.zip` into the SDK.
2. `./scripts/build-web.sh` → artifacts in `build/web/`.

### CI (on push to `main`)

Workflow `.github/workflows/build-web.yml`:

1. Download Ren'Py 8.5.3 SDK + web support.
2. Lint project.
3. `launcher web_build` → `build/web/`.
4. Push `build/web/` to **SoundGuyAI/RennyGame** branch **`gh-pages`** using secret **`RENNYGAME_DEPLOY_TOKEN`**.

Agents **cannot** set GitHub secrets. If deploy fails with auth errors, tell the user to verify the PAT secret and RennyGame Pages settings (see README).

Do not commit `build/web/` to Renny; deployment is CI-only.

## Game design document (GDD)

- Canonical doc: **`docs/GDD.md`**.
- **Do not** document the café test scene as the game's concept, genre, characters, or plot — it lives only in **GDD Appendix A**.
- When the **real** game is scoped or implemented, update the main GDD sections in the **same PR** as code changes.
- Keep unscoped design **TBD**; do not flesh out story canon unless the user or approved GDD sections define it.

## Workflow expectations

- Branch from `main`; use branch names like `cursor/<short-description>-45ca` when following cloud agent conventions.
- **Small, focused PRs** — one feature or doc pass per PR when possible.
- Commit messages: clear and complete sentences.
- After script changes: lint locally when SDK is available.
- Do not change deploy secrets, RennyGame repo settings, or workflow tokens unless the user asks.
- README is user-facing; AGENTS.md is agent-facing; GDD is design-facing — keep all three consistent.

## Quick reference

| Task | Command / location |
|------|---------------------|
| Run game | `renpy.sh /path/to/Renny` |
| Lint | `renpy.sh /path/to/Renny lint` |
| Web build | `./scripts/build-web.sh` |
| Play on phone | https://soundguyai.github.io/RennyGame/ |
| Design | `docs/GDD.md` |
