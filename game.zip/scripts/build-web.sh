#!/usr/bin/env bash
# Build Ren'Py web (HTML5) output locally. Requires SDK + web support under .renpy-sdk/.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VERSION="${RENPY_VERSION:-8.5.3.26051504}"
SHORT_VERSION="$(echo "$VERSION" | sed -E 's/([0-9]+\.[0-9]+\.[0-9]+)\..*/\1/')"

SDK_DIR="$ROOT/.renpy-sdk/renpy-${SHORT_VERSION}-sdk"

if [[ ! -x "$SDK_DIR/renpy.sh" ]]; then
  echo "Ren'Py SDK not found at $SDK_DIR"
  echo "Download ${SHORT_VERSION} SDK + web from https://github.com/renpy/renpy/releases"
  exit 1
fi

if [[ ! -d "$SDK_DIR/web" ]]; then
  echo "Ren'Py web support missing. Unzip renpy-${SHORT_VERSION}-web.zip into .renpy-sdk/ and copy web/ into the SDK."
  exit 1
fi

mkdir -p "$ROOT/build/web"
cd "$SDK_DIR"
./renpy.sh launcher web_build "$ROOT" --destination "$ROOT/build/web"
echo "Web build ready: $ROOT/build/web/index.html"
